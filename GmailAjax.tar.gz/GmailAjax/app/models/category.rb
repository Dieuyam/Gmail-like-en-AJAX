class Category < ApplicationRecord
  has_many :tasks
end
