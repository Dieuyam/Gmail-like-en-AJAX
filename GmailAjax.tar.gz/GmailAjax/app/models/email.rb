class Email < ApplicationRecord
end
